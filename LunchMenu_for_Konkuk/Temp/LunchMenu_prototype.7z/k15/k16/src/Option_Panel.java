package k15;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Option_Panel extends JFrame implements ActionListener {
	Main ma = new Main();
	
	Result_Panel result_Panel;
	Start_Panel start_Panel;
	Help_Panel help_Panel;

	JFrame frame;

	JPanel option_Panel;

	// �ּ� ����, �ִ� ���� �۾��� ��
	JTextField tf_Min_Cost;
	JTextField tf_Max_Cost;

	JButton btn_Search;
	JButton btn_Start;
	JButton btn_Home;
	JButton btn_Help;

	JLabel label_Select_Options;
	JLabel label_Theme;
	JLabel label_Location;
	JLabel label_Cost;
	JLabel label_Style;

	JLabel label_Select_Options_Deco;
	JLabel label_Theme_Deco;
	JLabel label_Location_Deco;
	JLabel label_Cost_Deco;
	JLabel label_Style_Deco;

	JRadioButton rb_Theme1;
	JRadioButton rb_Theme2;
	JRadioButton rb_Theme3;
	JRadioButton rb_Style1;
	JRadioButton rb_Style2;
	JRadioButton rb_Style3;
	JRadioButton rb_Style4;
	JRadioButton rb_Style5;
	JRadioButton rb_Style6;
	JRadioButton rb_Location1;
	JRadioButton rb_Location2;
	JRadioButton rb_Location3;

	ButtonGroup rbg_Theme;
	ButtonGroup rbg_Location;
	ButtonGroup rbg_Style;

	Option_Panel(JFrame _frame) {
		frame = _frame;

		// init
		option_Panel = new JPanel();

		// label ����
		label_Select_Options = new JLabel();
		label_Theme = new JLabel();
		label_Location = new JLabel();
		label_Cost = new JLabel();
		label_Style = new JLabel();

		label_Select_Options.setText("Select Options");
		label_Theme.setText("�׸���");
		label_Location.setText("��ġ");
		label_Cost.setText("���ݴ�");
		label_Style.setText("�з�");

		label_Select_Options.setOpaque(true);
		label_Theme.setOpaque(true);
		label_Location.setOpaque(true);
		label_Cost.setOpaque(true);
		label_Style.setOpaque(true);

		label_Select_Options.setBackground(Color.WHITE);
		label_Theme.setBackground(Color.LIGHT_GRAY);
		label_Location.setBackground(Color.LIGHT_GRAY);
		label_Cost.setBackground(Color.LIGHT_GRAY);
		label_Style.setBackground(Color.LIGHT_GRAY);

		label_Select_Options.setForeground(Color.BLACK);
		label_Theme.setForeground(Color.BLACK);
		label_Location.setForeground(Color.BLACK);
		label_Cost.setForeground(Color.BLACK);
		label_Style.setForeground(Color.BLACK);

		label_Select_Options.setFont(new Font("���� ����", 1, 16));
		label_Theme.setFont(new Font("���� ����", 1, 16));
		label_Location.setFont(new Font("���� ����", 1, 16));
		label_Cost.setFont(new Font("���� ����", 1, 16));
		label_Style.setFont(new Font("���� ����", 1, 16));

		// //////////
		label_Select_Options.setBounds(120, 80, 150, 60);
		label_Theme.setBounds(30, 170, 80, 64);
		label_Location.setBounds(30, 270, 80, 64);
		label_Cost.setBounds(30, 370, 80, 50);
		label_Style.setBounds(220, 170, 80, 164);
		// //////////

		label_Select_Options.setHorizontalAlignment(0);
		label_Theme.setHorizontalAlignment(0);
		label_Location.setHorizontalAlignment(0);
		label_Cost.setHorizontalAlignment(0);
		label_Style.setHorizontalAlignment(0);

		// for decoration - label
		label_Select_Options_Deco = new JLabel();
		label_Theme_Deco = new JLabel();
		label_Location_Deco = new JLabel();
		label_Cost_Deco = new JLabel();
		label_Style_Deco = new JLabel();

		label_Select_Options_Deco.setOpaque(true);
		label_Theme_Deco.setOpaque(true);
		label_Location_Deco.setOpaque(true);
		label_Cost_Deco.setOpaque(true);
		label_Style_Deco.setOpaque(true);

		label_Select_Options_Deco.setBackground(Color.BLACK);
		label_Theme_Deco.setBackground(Color.BLACK);
		label_Location_Deco.setBackground(Color.BLACK);
		label_Cost_Deco.setBackground(Color.BLACK);
		label_Style_Deco.setBackground(Color.BLACK);

		///////////////
		label_Select_Options_Deco.setBounds(label_Select_Options.getX() - 3, label_Select_Options.getY() - 3, 156, 66);
		label_Theme_Deco.setBounds(label_Theme.getX() - 3, label_Theme.getY() - 3, 86, 70);
		label_Location_Deco.setBounds(label_Location.getX() - 3, label_Location.getY() - 3, 86, 70);
		label_Cost_Deco.setBounds(label_Cost.getX() - 3, label_Cost.getY() - 3, 86, 56);
		label_Style_Deco.setBounds(label_Style.getX() - 3, label_Style.getY() - 3, 86, 170);
		///////////////

		//radiobutton setting
		rbg_Theme = new ButtonGroup();
		rbg_Style = new ButtonGroup();
		rbg_Location = new ButtonGroup();

		rb_Theme1 = new JRadioButton();
		rb_Theme2 = new JRadioButton();
		rb_Theme3 = new JRadioButton();
		rb_Style1 = new JRadioButton();
		rb_Style2 = new JRadioButton();
		rb_Style3 = new JRadioButton();
		rb_Style4 = new JRadioButton();
		rb_Style5 = new JRadioButton();
		rb_Style6 = new JRadioButton();
		rb_Location1 = new JRadioButton();
		rb_Location2 = new JRadioButton();
		rb_Location3 = new JRadioButton();

		rb_Theme1.setBackground(Color.WHITE);
		rb_Theme2.setBackground(Color.WHITE);
		rb_Theme3.setBackground(Color.WHITE);
		rb_Style1.setBackground(Color.WHITE);
		rb_Style2.setBackground(Color.WHITE);
		rb_Style3.setBackground(Color.WHITE);
		rb_Style4.setBackground(Color.WHITE);
		rb_Style5.setBackground(Color.WHITE);
		rb_Style6.setBackground(Color.WHITE);
		rb_Location1.setBackground(Color.WHITE);
		rb_Location2.setBackground(Color.WHITE);
		rb_Location3.setBackground(Color.WHITE);

		rb_Theme1.setText("����Ʈ");
		rb_Theme2.setText("ȸ��/����");
		rb_Theme3.setText("ģ���� �Բ�");
		rb_Style1.setText("�ѽ�");
		rb_Style2.setText("�н�");
		rb_Style3.setText("�Ͻ�");
		rb_Style4.setText("�߽�");
		rb_Style5.setText("���");
		rb_Style6.setText("�н�ƮǪ��");
		rb_Location1.setText("�Ĺ�");
		rb_Location2.setText("�߹�");
		rb_Location3.setText("����");
		
		rb_Theme1.setFont(new Font("���� ����", 0, 12));
		rb_Theme2.setFont(new Font("���� ����", 0, 12));
		rb_Theme3.setFont(new Font("���� ����", 0, 12));
		rb_Style1.setFont(new Font("���� ����", 0, 12));
		rb_Style2.setFont(new Font("���� ����", 0, 12));
		rb_Style3.setFont(new Font("���� ����", 0, 12));
		rb_Style4.setFont(new Font("���� ����", 0, 12));
		rb_Style5.setFont(new Font("���� ����", 0, 12));
		rb_Style6.setFont(new Font("���� ����", 0, 12));
		rb_Location1.setFont(new Font("���� ����", 0, 12));
		rb_Location2.setFont(new Font("���� ����", 0, 12));
		rb_Location3.setFont(new Font("���� ����", 0, 12));

		rb_Theme1.setBounds(label_Theme_Deco.getX()+88, label_Theme_Deco.getY(), 90, 20);
		rb_Theme2.setBounds(label_Theme_Deco.getX()+88, label_Theme_Deco.getY()+24, 90, 20);
		rb_Theme3.setBounds(label_Theme_Deco.getX()+88, label_Theme_Deco.getY()+48, 90, 20);
		rb_Style1.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY(), 90, 20);
		rb_Style2.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY()+24, 90, 20);
		rb_Style3.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY()+48, 90, 20);
		rb_Style4.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY()+72, 90, 20);
		rb_Style5.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY()+96, 90, 20);
		rb_Style6.setBounds(label_Style_Deco.getX()+88, label_Style_Deco.getY()+120, 90, 20);
		rb_Location1.setBounds(label_Location_Deco.getX()+88, label_Location_Deco.getY(), 90, 20);
		rb_Location2.setBounds(label_Location_Deco.getX()+88, label_Location_Deco.getY()+24, 90, 20);
		rb_Location3.setBounds(label_Location_Deco.getX()+88, label_Location_Deco.getY()+48, 90, 20);

		rbg_Theme.add(rb_Theme1);
		rbg_Theme.add(rb_Theme2);
		rbg_Theme.add(rb_Theme3);
		rbg_Theme.add(rb_Theme1);
		rbg_Style.add(rb_Style2);
		rbg_Style.add(rb_Style3);
		rbg_Style.add(rb_Style4);
		rbg_Style.add(rb_Style5);
		rbg_Style.add(rb_Style6);
		rbg_Location.add(rb_Location1);
		rbg_Location.add(rb_Location2);
		rbg_Location.add(rb_Location3);

/*		rb_Theme1.set
		rb_Theme2.setUserData("2");
		rb_Theme3.setUserData("3");
		rb_Theme1.setToggleGroup(theme_Group);
		
		theme_Group.selectedToggleProperty().addListener(
				(ObservableValue<? extends Toggle> ov, Toggle old_toggle,
						Toggle new_togle) -> {
							if (theme_Group.getSelectedToggle() != null) {
								
							}
						});*/

		// textfield setting
		tf_Min_Cost = new JTextField(5);
		tf_Max_Cost = new JTextField(5);

		tf_Min_Cost.setFont(new Font("���� ����", 0, 15));
		tf_Max_Cost.setFont(new Font("���� ����", 0, 15));

		tf_Min_Cost.setBounds(130, 375, 60, 40);
		tf_Max_Cost.setBounds(220, 375, 60, 40);

		//button setting
		btn_Search = new JButton();
		btn_Start = new JButton();
		btn_Home = new JButton();
		btn_Help = new JButton();
		
		btn_Search.setText("Search");
		btn_Start.setText("Start");
		btn_Home.setText("H");
		btn_Help.setText("Help");

		btn_Search.setBounds(20, 20, 75, 50);
		btn_Start.setBounds(20, 455, 145, 50);
		btn_Home.setBounds(175, 455, 50, 50);
		btn_Help.setBounds(235, 455, 145, 50);

		btn_Search.setBackground(Color.LIGHT_GRAY);
		btn_Start.setBackground(Color.LIGHT_GRAY);
		btn_Home.setBackground(Color.LIGHT_GRAY);
		btn_Help.setBackground(Color.LIGHT_GRAY);

		btn_Search.setFont(new Font("���� ����", 1, 12));
		btn_Start.setFont(new Font("���� ����", 1, 25));
		btn_Home.setFont(new Font("���� ����", 1, 20));
		btn_Help.setFont(new Font("���� ����", 1, 25));


		// setBounds : ��ġ�� ũ�⸦ �����Ѵ�.
		// frame.getWidth() : frame�� �ʺ� �ҷ����� �Լ�
		// frame.getHeight() : frame�� ���̸� �ҷ����� �Լ�
		option_Panel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
		option_Panel.setBackground(Color.WHITE);
		option_Panel.setLayout(null);

		// actionlistener
		btn_Search.addActionListener(this);
		btn_Start.addActionListener(this);
		btn_Home.addActionListener(this);
		btn_Help.addActionListener(this);

		// add
		option_Panel.add(rb_Theme1);
		option_Panel.add(rb_Theme2);
		option_Panel.add(rb_Theme3);
		option_Panel.add(rb_Style1);
		option_Panel.add(rb_Style2);
		option_Panel.add(rb_Style3);
		option_Panel.add(rb_Style4);
		option_Panel.add(rb_Style5);
		option_Panel.add(rb_Style6);
		option_Panel.add(rb_Location1);
		option_Panel.add(rb_Location2);
		option_Panel.add(rb_Location3);

		option_Panel.add(label_Select_Options);
		option_Panel.add(label_Theme);
		option_Panel.add(label_Location);
		option_Panel.add(label_Cost);
		option_Panel.add(label_Style);
		option_Panel.add(label_Select_Options_Deco);
		option_Panel.add(label_Theme_Deco);
		option_Panel.add(label_Location_Deco);
		option_Panel.add(label_Cost_Deco);
		option_Panel.add(label_Style_Deco);

		option_Panel.add(tf_Min_Cost);
		option_Panel.add(tf_Max_Cost);

		option_Panel.add(btn_Search);
		option_Panel.add(btn_Start);
		option_Panel.add(btn_Home);
		option_Panel.add(btn_Help);

		frame.add(option_Panel);

		option_Panel.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == btn_Start) {
			// �ƹ��͵� ������� �ʴ´�.
		} else if (e.getSource() == btn_Home) {
			option_Panel.setVisible(false);
			start_Panel = new Start_Panel(frame);
		} else if (e.getSource() == btn_Help) {
			System.out.println("Click Help");
			option_Panel.setVisible(false);
			help_Panel = new Help_Panel(frame);
		} else if (e.getSource() == btn_Search) {
			check();
			option_Panel.setVisible(false);
			result_Panel = new Result_Panel(frame);
			System.out.println("Search ����");
		}
	}
	
	public void check(){
		// RadioButton �׼� : ���� �� �߰�.
				if (rb_Theme1.isSelected()) {
					ma.select_Theme = 1;
					System.out.println("1�� ���õ�");
				} else if (rb_Theme2.isSelected()) {
					ma.select_Theme = 2;
				} else if (rb_Theme2.isSelected()) {
					ma.select_Theme = 3;
				}
				if (rb_Style1.isSelected()) {
					ma.select_Style = 1;
				} else if (rb_Style2.isSelected()) {
					ma.select_Style = 2;
				} else if (rb_Style2.isSelected()) {
					ma.select_Style = 3;
				} else if (rb_Style2.isSelected()) {
					ma.select_Style = 4;
				} else if (rb_Style2.isSelected()) {
					ma.select_Style = 5;
				} else if (rb_Style2.isSelected()) {
					ma.select_Style = 6;
				}
				if (rb_Location1.isSelected()) {
					ma.select_Location = 1;
				} else if (rb_Location2.isSelected()) {
					ma.select_Location = 2;
				} else if (rb_Location2.isSelected()) {
					ma.select_Location = 3;
				}
	}
}