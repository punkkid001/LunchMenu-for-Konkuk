package k15;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Help_Panel implements ActionListener{
	Option_Panel option_Panel;
	Start_Panel start_Panel;
	
	JFrame frame;
	
	JPanel help_Panel;
	
	JLabel label_Help1;
	JLabel label_Help2;
	JLabel label_Help3;
	
	JButton btn_Start;
	JButton btn_Home;
	JButton btn_Help;

	
	Help_Panel(JFrame _frame){
		frame = _frame;

		help_Panel = new JPanel();
		help_Panel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
		help_Panel.setBackground(Color.WHITE);
		
		help_Panel.setLayout(null);
		
		//button setting
		btn_Start = new JButton();
		btn_Home = new JButton();
		btn_Help = new JButton();
		
		btn_Start.setText("Start");
		btn_Home.setText("H");
		btn_Help.setText("Help");
		
		btn_Start.setBounds(20, 455, 145, 50);
		btn_Home.setBounds(175, 455, 50, 50);
		btn_Help.setBounds(235, 455, 145, 50);

		btn_Start.setBackground(Color.LIGHT_GRAY);
		btn_Home.setBackground(Color.LIGHT_GRAY);
		btn_Help.setBackground(Color.LIGHT_GRAY);

		btn_Start.setFont(new Font("���� ����", 1, 25));
		btn_Home.setFont(new Font("���� ����", 1, 20));
		btn_Help.setFont(new Font("���� ����", 1, 25));
		
		//labet setting
		label_Help1 = new JLabel();
		label_Help2 = new JLabel();
		label_Help3 = new JLabel();
		
		label_Help1.setText("test1");
		label_Help2.setText("test2");
		label_Help3.setText("test3");
		
		label_Help1.setFont(new Font("���� ����",0,15));
		label_Help2.setFont(new Font("���� ����",0,15));
		label_Help3.setFont(new Font("���� ����",0,15));
		
		label_Help1.setBounds(30,100,340,100);
		label_Help2.setBounds(30,200,340,100);
		label_Help3.setBounds(30,300,340,100);
		
		// add
		help_Panel.add(label_Help1);
		help_Panel.add(label_Help2);
		help_Panel.add(label_Help3);
		help_Panel.add(btn_Start);
		help_Panel.add(btn_Home);
		help_Panel.add(btn_Help);

		frame.add(help_Panel);

		//add actionlistener
		btn_Start.addActionListener(this);
		btn_Home.addActionListener(this);
		btn_Help.addActionListener(this);

		help_Panel.setVisible(true);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == btn_Start) {
			System.out.println("Click Start");
			help_Panel.setVisible(false);
			option_Panel = new Option_Panel(frame);
		}else if (e.getSource() == btn_Home) {
			System.out.println("Click H");
			help_Panel.setVisible(false);
			start_Panel = new Start_Panel(frame);
		}else if (e.getSource() == btn_Help) {
			System.out.println("Click Help");
		}
	
	}
}
