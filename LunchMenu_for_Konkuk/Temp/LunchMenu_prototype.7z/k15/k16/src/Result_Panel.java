package k15;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Result_Panel extends JFrame implements ActionListener {
	
	Main ma = new Main();
	
	Option_Panel option_Panel;
	Start_Panel start_Panel;
	Help_Panel help_Panel;

	JFrame frame;
	// ��� �� ǥ�� �г� ����
	JPanel result_Panel;

	JButton btn_Start;
	JButton btn_Home;
	JButton btn_Help;

	JLabel label1;
	JLabel label2;

	JButton btn1;
	JButton btn2;
	JButton btn3;
	JButton btn4;
	JButton btn5;
	JButton btn6;
	JButton btn7;
	JButton btn8;
	JButton btn9;
	JButton btn10;
	JButton btn11;
	JButton btn12;
	JButton btn13;
	JButton btn14;
	JButton btn15;
	JButton btn16;
	JButton btn17;
	JButton btn18;
	JButton btn19;
	JButton btn20;
	JButton btn21;
	JButton btn22;
	JButton btn23;
	JButton btn24;
	JButton btn25;
	JButton btn26;
	JButton btn27;
	JButton btn28;
	JButton btn29;
	JButton btn30;
	JButton btn31;
	JButton btn32;
	JButton btn33;
	JButton btn34;
	JButton btn35;
	JButton btn36;
	
	Result_Panel(JFrame _frame) {
		System.out.println("Panel �����");
		frame = _frame;
		
		result_Panel = new JPanel();
		result_Panel.setBounds(0, 0, frame.getWidth(), frame.getHeight());
		result_Panel.setBackground(Color.WHITE);
		result_Panel.setLayout(null);
		
		//button setting
		btn_Start = new JButton();
		btn_Home = new JButton();
		btn_Help = new JButton();
		
		btn_Start.setText("Start");
		btn_Home.setText("H");
		btn_Help.setText("Help");
		
		btn_Start.setBounds(20, 455, 145, 50);
		btn_Home.setBounds(175, 455, 50, 50);
		btn_Help.setBounds(235, 455, 145, 50);

		btn_Start.setBackground(Color.LIGHT_GRAY);
		btn_Home.setBackground(Color.LIGHT_GRAY);
		btn_Help.setBackground(Color.LIGHT_GRAY);

		btn_Start.setFont(new Font("���� ����", 1, 25));
		btn_Home.setFont(new Font("���� ����", 1, 20));
		btn_Help.setFont(new Font("���� ����", 1, 25));
		
		// add actionlistener
		btn_Start.addActionListener(this);
		btn_Home.addActionListener(this);
		btn_Help.addActionListener(this);

		Color newGreen = new Color(0, 126, 57);

		label1=new JLabel();
		label1.setText("Result");
		label1.setBounds(150, 100, 100, 50);
		label1.setOpaque(true);
		label1.setForeground(newGreen);
		label1.setBackground(Color.WHITE);
		label1.setFont(new Font("���� ����", 1, 30));

		label2=new JLabel();
		label2.setBounds(100, 150, 200, 250);
		label2.setLayout(new FlowLayout());
		aa();
		
		//add
		result_Panel.add(label1);
		result_Panel.add(label2);
		result_Panel.add(btn_Start);
		result_Panel.add(btn_Home);
		result_Panel.add(btn_Help);

		frame.add(result_Panel);
		
		// add actionlistener
		btn_Start.addActionListener(this);
		btn_Home.addActionListener(this);
		btn_Help.addActionListener(this);

		label1.setVisible(true);
		label2.setVisible(true);
		
		result_Panel.setVisible(true);
		
	}

	public void aa() {
		if (ma.select_Location == 1 && ma.select_Style == 1) {
			Koreanback();
		} else if (ma.select_Location == 2 && ma.select_Style == 1) {
			Koreanmiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 1) {
			Koreanfront();
		} else if (ma.select_Location == 1 && ma.select_Style == 2) {
			snackback();
		} else if (ma.select_Location == 2 && ma.select_Style == 2) {
			snackmiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 2) {
			snackfront();
		} else if (ma.select_Location == 1 && ma.select_Style == 3) {
			Japaneseback();
		} else if (ma.select_Location == 2 && ma.select_Style == 3) {
			Japanesemiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 3) {
			Japanesefront();
		} else if (ma.select_Location == 1 && ma.select_Style == 4) {
			Chineseback();
		} else if (ma.select_Location == 2 && ma.select_Style == 4) {
			Chinesemiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 4) {
			Chinesefront();
		} else if (ma.select_Location == 1 && ma.select_Style == 5) {
			Westernback();
		} else if (ma.select_Location == 2 && ma.select_Style == 5) {
			Westernmiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 5) {
			Westernfront();
		} else if (ma.select_Location == 1 && ma.select_Style == 6) {
			fastfoodback();
		} else if (ma.select_Location == 2 && ma.select_Style == 6) {
			fastfoodmiddle();
		} else if (ma.select_Location == 3 && ma.select_Style == 6) {
			fastfoodfront();
		} 
	}

	public void Koreanback() {
		btn20 = new JButton(new ImageIcon("Korean 2.png"));
		btn21 = new JButton(new ImageIcon("Korean 3.png"));
		btn20.setBackground(Color.WHITE);
		btn21.setBackground(Color.WHITE);
		label2.add(btn20);
		label2.add(btn21);
	}

	public void Koreanmiddle() {
		btn19 = new JButton(new ImageIcon("Korean 1.png"));
		btn24 = new JButton(new ImageIcon("Korean 6.png"));
		btn25 = new JButton(new ImageIcon("Korean 7.png"));
		btn19.setBackground(Color.WHITE);
		btn24.setBackground(Color.WHITE);
		btn25.setBackground(Color.WHITE);
		label2.add(btn19);
		label2.add(btn24);
		label2.add(btn25);
	}

	public void Koreanfront() {
		btn22 = new JButton(new ImageIcon("Korean 4.png"));
		btn23 = new JButton(new ImageIcon("Korean 5.png"));
		btn22.setBackground(Color.WHITE);
		btn23.setBackground(Color.WHITE);
		label2.add(btn22);
		label2.add(btn23);
	}

	public void fastfoodfront() {
		btn8 = new JButton(new ImageIcon("fastfood 2.png"));
		btn11 = new JButton(new ImageIcon("fastfood 5.png"));
		btn8.setBackground(Color.WHITE);
		btn11.setBackground(Color.WHITE);
		label2.add(btn8);
		label2.add(btn11);
	}

	public void fastfoodmiddle() {
		btn9 = new JButton(new ImageIcon("fastfood 3.png"));
		btn10 = new JButton(new ImageIcon("fastfood 4.png"));
		btn9.setBackground(Color.WHITE);
		btn10.setBackground(Color.WHITE);
		label2.add(btn9);
		label2.add(btn10);
	}

	public void fastfoodback() {
		btn7 = new JButton(new ImageIcon("fastfood 1.png"));
		btn12 = new JButton(new ImageIcon("fastfood 6.png"));
		btn7.setBackground(Color.WHITE);
		btn12.setBackground(Color.WHITE);
		label2.add(btn7);
		label2.add(btn12);
	}

	public void Chinesefront() {
		btn1 = new JButton(new ImageIcon("Chinese 1.png"));
		btn6 = new JButton(new ImageIcon("Chinese 6.png"));
		btn1.setBackground(Color.WHITE);
		btn6.setBackground(Color.WHITE);
		label2.add(btn1);
		label2.add(btn6);
	}

	public void Chinesemiddle() {
		btn2 = new JButton(new ImageIcon("Chinese 2.png"));
		btn5 = new JButton(new ImageIcon("Chinese 5.png"));
		btn2.setBackground(Color.WHITE);
		btn5.setBackground(Color.WHITE);
		label2.add(btn2);
		label2.add(btn5);
	}

	public void Chineseback() {
		btn3 = new JButton(new ImageIcon("Chinese 3.png"));
		btn4 = new JButton(new ImageIcon("Chinese 4.png"));
		btn3.setBackground(Color.WHITE);
		btn4.setBackground(Color.WHITE);
		label2.add(btn3);
		label2.add(btn4);
	}

	public void Westernfront() {
		btn36 = new JButton(new ImageIcon("Western 6.png"));
		btn36.setBackground(Color.WHITE);
		label2.add(btn36);
	}

	public void Westernmiddle() {
		btn31 = new JButton(new ImageIcon("Western 1.png"));
		btn35 = new JButton(new ImageIcon("Western 5.png"));
		btn31.setBackground(Color.WHITE);
		btn35.setBackground(Color.WHITE);
		label2.add(btn31);
		label2.add(btn35);
	}

	public void Westernback() {
		btn32 = new JButton(new ImageIcon("Western 2.png"));
		btn33 = new JButton(new ImageIcon("Western 3.png"));
		btn34 = new JButton(new ImageIcon("Western 4.png"));
		btn32.setBackground(Color.WHITE);
		btn33.setBackground(Color.WHITE);
		btn34.setBackground(Color.WHITE);
		label2.add(btn32);
		label2.add(btn33);
		label2.add(btn34);
	}

	public void snackfront() {
		JButton btn30 = new JButton(new ImageIcon("snack 5.png"));
		btn30.setBackground(Color.WHITE);
		label2.add(btn30);
	}

	public void snackmiddle() {
		btn27 = new JButton(new ImageIcon("snack 2.png"));
		btn28 = new JButton(new ImageIcon("snack 3.png"));
		btn27.setBackground(Color.WHITE);
		btn28.setBackground(Color.WHITE);
		label2.add(btn27);
		label2.add(btn28);
	}

	public void snackback() {
		btn26 = new JButton(new ImageIcon("snack 1.png"));
		btn29 = new JButton(new ImageIcon("snack 4.png"));
		btn26.setBackground(Color.WHITE);
		btn29.setBackground(Color.WHITE);
		label2.add(btn26);
		label2.add(btn29);
	}

	public void Japaneseback() {

	}

	public void Japanesemiddle() {
		btn14 = new JButton(new ImageIcon("Japanese 2.png"));
		btn15 = new JButton(new ImageIcon("Japanese 3.png"));
		btn17 = new JButton(new ImageIcon("Japanese 5.png"));
		btn18 = new JButton(new ImageIcon("Japanese 6.png"));
		btn14.setBackground(Color.WHITE);
		btn15.setBackground(Color.WHITE);
		btn17.setBackground(Color.WHITE);
		btn18.setBackground(Color.WHITE);
		label2.add(btn14);
		label2.add(btn15);
		label2.add(btn17);
		label2.add(btn18);
	}

	public void Japanesefront() {
		JButton btn13 = new JButton(new ImageIcon("Japanese 1.png"));
		JButton btn16 = new JButton(new ImageIcon("Japanese 4.png"));
		btn13.setBackground(Color.WHITE);
		btn16.setBackground(Color.WHITE);
		label2.add(btn13);
		label2.add(btn16);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == btn_Start) {
			result_Panel.setVisible(false);
			option_Panel = new Option_Panel(frame);
		} else if (e.getSource() == btn_Home) {
			result_Panel.setVisible(false);
			start_Panel = new Start_Panel(frame);
		} else if (e.getSource() == btn_Help) {
			result_Panel.setVisible(false);
			help_Panel = new Help_Panel(frame);
		
       if(e.getSource() == btn1)
       {
          remove();
          menu(1);
       }
       else if(e.getSource() == btn2)
       {
          remove();
          menu(2);
       }
       else if(e.getSource() == btn3)
       {
          remove();
          menu(3);
       }
       else if(e.getSource() == btn4)
       {
          remove();
          menu(4);
       }
       else if(e.getSource() == btn5)
       {
          remove();
          menu(5);
       }
       else if(e.getSource() == btn6)
       {
          remove();
          menu(6);
       }
       else if(e.getSource() == btn7)
       {
          remove();
          menu(7);
       }
       else if(e.getSource() == btn8)
       {
          remove();
          menu(8);
       }
       else if(e.getSource() == btn9)
       {
          remove();
          menu(9);
       }
       else if(e.getSource() == btn10)
       {
          remove();
          menu(10);
       }
       else if(e.getSource() == btn11)
       {
          remove();
          menu(11);
       }
       else if(e.getSource() == btn12)
       {
          remove();
          menu(12);
       }
       else if(e.getSource() == btn13)
       {
          remove();
          menu(13);
       }
       else if(e.getSource() == btn14)
       {
          remove();
          menu(14);
       }
       else if(e.getSource() == btn15)
       {
          remove();
          menu(15);
       }
       else if(e.getSource() == btn16)
       {
          remove();
          menu(16);
       }
       else if(e.getSource() == btn17)
       {
          remove();
          menu(17);
       }
       else if(e.getSource() == btn18)
       {
          remove();
          menu(18);
       }
       else if(e.getSource() == btn19)
       {
          remove();
          menu(19);
       }
       else if(e.getSource() == btn20)
       {
          remove();
          menu(20);
       }
       else if(e.getSource() == btn21)
       {
          remove();
          menu(21);
       }
       else if(e.getSource() == btn22)
       {
          remove();
          menu(22);
       }
       else if(e.getSource() == btn23)
       {
          remove();
          menu(23);
       }
       else if(e.getSource() == btn24)
       {
          remove();
          menu(24);
       }
       else if(e.getSource() == btn25)
       {
          remove();
          menu(25);
       }
       else if(e.getSource() == btn26)
       {
          remove();
          menu(26);
       }
       else if(e.getSource() == btn27)
       {
          remove();
          menu(27);
       }
       else if(e.getSource() == btn28)
       {
          remove();
          menu(28);
       }
       else if(e.getSource() == btn29)
       {
          remove();
          menu(29);
       }
       else if(e.getSource() == btn30)
       {
          remove();
          menu(30);
       }
       else if(e.getSource() == btn31)
       {
          remove();
          menu(31);
       }
       else if(e.getSource() == btn32)
       {
          remove();
          menu(32);
       }
       else if(e.getSource() == btn33)
       {
          remove();
          menu(33);
       }
       else if(e.getSource() == btn34)
       {
          remove();
          menu(34);
       }
       else if(e.getSource() == btn35)
       {
          remove();
          menu(35);
       }
       else if(e.getSource() == btn36)
       {
          remove();
          menu(36);
       }
    }
 }
 
 public void menu(int a)
 {
    if(a == 1)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�ϻͳ��͸޴�.png"));
    }
    else if(a == 2)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�����޴�.png"));
    }
    else if(a == 3)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ȫ����ȭ�丮�޴�.png"));
    }
    else if(a == 4)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�������޴�.png"));
    }
    else if(a == 5)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("����ó�޴�.png"));
    }
    else if(a == 6)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ȫ������޴�.png"));
    }
    else if(a == 7)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�Ƴ볯��.jpg"));
    }
    else if(a == 8)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("����ŷ.jpg"));
    }
    else if(a == 9)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("��ġŲ.jpg"));
    }
    else if(a == 10)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("������.jpg"));
    }
    else if(a == 11)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("����ũ��ġ.jpg"));
    }
    else if(a == 12)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("������.jpg"));
    }
    else if(a == 13)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("jin.png"));
    }
    else if(a == 14)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("������.png"));
    }
    else if(a == 15)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("jin.png"));
    }
    else if(a == 16)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�շ��� �쵿.png"));
    }
    else if(a == 17)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ȣ��.png"));
    }
    else if(a == 18)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("��ٸ�.png"));
    }
    else if(a == 19)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("������ߺн�.jpg"));
    }
    else if(a == 20)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("���� ����.png"));
    }
    else if(a == 21)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("����.png"));
    }
    else if(a == 22)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("���� ���.png"));
    }
    else if(a == 23)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�̽��� ���κ�.png"));
    }
    else if(a == 24)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�޲ٹ�ŷ.png"));
    }
    else if(a == 25)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�� ����.png"));
    }
    else if(a == 26)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�����������.jpg"));
    }
    else if(a == 27)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("���Ƕ�.jpg"));
    }
    else if(a == 28)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ũ��������.jpg"));
    }
    else if(a == 29)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�ҳ�������.jpg"));
    }
    else if(a == 30)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�ڽ�����.jpg"));
    }
    else if(a == 31)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ī�Ϲ� ����.png"));
    }
    else if(a == 32)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("ȭ�� ����.png"));
    }
    else if(a == 33)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("��������.png"));
    }
    else if(a == 34)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("�Ž��׸�.png"));
    }
    else if(a == 35)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("���콺����ũ.png"));
    }
    else if(a == 36)
    {
       JLabel label = new JLabel();
       add(label);
       label.setIcon(new ImageIcon("BRCD.png"));
    }
 }
 
 public void remove()
 {
    getContentPane().remove(btn1);
    getContentPane().remove(btn2);
    getContentPane().remove(btn3);
    getContentPane().remove(btn4);
    getContentPane().remove(btn5);
    getContentPane().remove(btn6);
    getContentPane().remove(btn7);
    getContentPane().remove(btn8);
    getContentPane().remove(btn9);
    getContentPane().remove(btn10);
    getContentPane().remove(btn11);
    getContentPane().remove(btn12);
    getContentPane().remove(btn13);
    getContentPane().remove(btn14);
    getContentPane().remove(btn15);
    getContentPane().remove(btn16);
    getContentPane().remove(btn17);
    getContentPane().remove(btn18);
    getContentPane().remove(btn19);
    getContentPane().remove(btn20);
    getContentPane().remove(btn21);
    getContentPane().remove(btn22);
    getContentPane().remove(btn23);
    getContentPane().remove(btn24);
    getContentPane().remove(btn25);
    getContentPane().remove(btn26);
    getContentPane().remove(btn27);
    getContentPane().remove(btn28);
    getContentPane().remove(btn29);
    getContentPane().remove(btn30);
    getContentPane().remove(btn31);
    getContentPane().remove(btn32);
    getContentPane().remove(btn33);
    getContentPane().remove(btn34);
    getContentPane().remove(btn35);
    getContentPane().remove(btn36);
 }
}